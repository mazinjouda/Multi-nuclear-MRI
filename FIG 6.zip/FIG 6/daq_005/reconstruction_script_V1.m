k = [];

for i = 1:64
    x = dev2231.demods(1).sample_x_avg{1, i}.value(1:end);
    x = decimate(x,fix(length(x)/64));
    y = dev2231.demods(1).sample_y_avg{1, i}.value(1:end);
    y = decimate(y,fix(length(y)/64));
    k(i,:) = x + 1j*y;
end
figure, imshow(mat2gray(abs(fftshift(fft2(k)))))

%%
k = [];

for i = 1:64
    x = dev2231.demods(5).sample_x{1, i}.value(1:end);
    x = decimate(x,fix(length(x)/64));
    y = dev2231.demods(5).sample_y{1, i}.value(1:end);
    y = decimate(y,fix(length(y)/64));
    k(i,:) = x + 1j*y;
end
figure, imshow(mat2gray(abs(fftshift(fft2(k)))))